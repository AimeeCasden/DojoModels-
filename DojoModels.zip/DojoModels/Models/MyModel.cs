using System;


namespace DojoModels.Models
{
    public class Survey
    {
       public string FirstName { get ; set;}
       public string Location { get; set ;}
       public string Language { get; set;}
       public string Comment { get; set;}
    }
}
﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using DojoModels.Models;

namespace DojoModels.Controllers
{
    public class HomeController : Controller
    {
        [Route("")]
        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }
        [Route("result")]
        [HttpPost]

        public IActionResult Result(string name, string location, string language, string comment)
        {
            ViewBag.name  =  Request.Form["name"];
            ViewBag.location  =  Request.Form["location"];
            ViewBag.language  =  Request.Form["language"];
            ViewBag.comment  =  Request.Form["comment"];

            return View("result");
        }


    }
}
